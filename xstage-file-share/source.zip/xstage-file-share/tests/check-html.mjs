import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
for (const f of ['app/src/main/assets/portal.html','app/src/main/assets/remote.html']) {
  const html=fs.readFileSync(f,'utf8');
  const scripts=[...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(x=>x[1]).filter(x=>x.trim());
  assert.ok(scripts.length,'inline script present '+f);
  for(const s of scripts)new vm.Script(s,{filename:f});
  assert.match(html,/X-Stage File Share/);
  console.log('PASS: HTML JavaScript parses: '+f);
}

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/lan-smoke
javac -encoding UTF-8 -d build/lan-smoke app/src/main/java/com/webbasex/xstage/fileshare/LanHttpServer.java tests/LanHttpServerTest.java
java -cp build/lan-smoke com.webbasex.xstage.fileshare.LanHttpServerTest
node tests/check-html.mjs

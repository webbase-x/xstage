package com.webbasex.xstage.fileshare;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;

public class LanHttpServerTest {
    static byte[] request(int port, String raw, byte[] body) throws Exception {
        try(Socket s = new Socket("127.0.0.1", port)) {
            s.setSoTimeout(3000);
            OutputStream o=s.getOutputStream(); o.write(raw.getBytes("ISO-8859-1"));if(body!=null)o.write(body);o.flush();
            ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
            while((n=s.getInputStream().read(buf))!=-1)b.write(buf,0,n);return b.toByteArray();
        }
    }
    static String str(byte[] b) { return new String(b,java.nio.charset.StandardCharsets.ISO_8859_1); }
    static void check(boolean ok,String why) { if(!ok)throw new AssertionError(why); }
    public static void main(String[] args)throws Exception{
        Path base=Files.createTempDirectory("xstage-file-share-test");
        try(LanHttpServer server=new LanHttpServer(base.resolve("received"),base.resolve("send"),"<h1>READY</h1>", (name, peer)->{})){
            server.start(); int port=server.port();check(port>0,"port");
            String raw=str(request(port,"GET / HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\n\r\n",null));
            check(raw.startsWith("HTTP/1.1 401"),"auth required");
            String target=server.connectionUrl("127.0.0.1");
            String token=target.substring(target.indexOf("/connect"));
            String login=str(request(port,"GET "+token+" HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\n\r\n",null));
            check(login.startsWith("HTTP/1.1 302"),"pair");
            String cookie=login.split("Set-Cookie: ")[1].split(";")[0];
            String allowed=str(request(port,"GET / HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\nCookie: "+cookie+"\r\n\r\n",null));
            check(allowed.contains("READY"),"portal");
            byte[] bytes="hello-file-share".getBytes("UTF-8");
            String prefix="POST /api/upload HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\nOrigin: http://127.0.0.1:"+port+"\r\nCookie: "+cookie+"\r\nX-File-Name: demo.txt\r\nContent-Length: "+bytes.length+"\r\n\r\n";
            check(str(request(port,prefix,bytes)).startsWith("HTTP/1.1 200"),"upload");
            check(Files.readString(base.resolve("received/demo.txt")).equals("hello-file-share"),"saved data");
            check(str(request(port,prefix,bytes)).contains("demo (1).txt"),"duplicate name");
            check(str(request(port,prefix.replace("Origin: http://127.0.0.1", "Origin: http://attacker.invalid"),bytes)).startsWith("HTTP/1.1 403"),"origin check");
            server.setMode(LanHttpServer.Mode.SEND);
            check(str(request(port,"GET /api/state HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\nCookie: "+cookie+"\r\n\r\n",null)).startsWith("HTTP/1.1 401"),"role revokes session");
            Files.writeString(base.resolve("send/song.mp3"),"audio");
            String refreshed=str(request(port,"GET "+server.connectionUrl("127.0.0.1").substring(target.indexOf("/connect")) +" HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\n\r\n",null));
            String cookie2=refreshed.split("Set-Cookie: ")[1].split(";")[0];
            check(str(request(port,"GET /download?name=song.mp3 HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\nCookie: "+cookie2+"\r\n\r\n",null)).endsWith("audio"),"download");
            check(str(request(port,"GET /download?name=..%2Fsecret HTTP/1.1\r\nHost: 127.0.0.1:"+port+"\r\nCookie: "+cookie2+"\r\n\r\n",null)).startsWith("HTTP/1.1 400"),"traversal blocked");
        }
        System.out.println("PASS: LAN pairing, upload, duplicate, origin, mode revocation, download, traversal");
    }
}

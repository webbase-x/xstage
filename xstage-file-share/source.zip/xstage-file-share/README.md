# X-Stage File Share v0.1.0-preview.1

Android 6.0+ (API 23), phone, tablet, Android TV/TrueID-type boxes (physical device testing required).

- Android app starts a foreground file server, default RECEIVE. Role SEND lets user import any file type from Android's document picker.
- Scan QR with the other device; browser client installs nothing. The app supports multiple browser sessions; received files remain in app-specific storage and can be opened with Android FileProvider.
- LAN (offline): QR points at Android's private IP and port. Files transfer directly with cookie pairing, strict same-origin upload policy, streamed file writes and streaming downloads.
- Internet: once PeerJS signaling connects in the WebView, QR switches to HTTPS `https://webbase-x.github.io/xstage/file-share/#connect=<ephemeral-id>`. Multiple browsers can connect using encrypted WebRTC DataChannels (WebRTC chooses the working network route). The Android host persists incoming chunks locally, not in cloud storage. PeerServer Cloud is used only for signaling and public STUN for ICE, not storing file data.
- Internet **is best-effort**. Symmetric NAT, carrier gateways and restrictive firewalls often require TURN relay; no TURN service is configured in this preview. The Android device must keep its app activity alive for the WebView-based Internet host. WebView support differs across TV boxes. When remote signaling is unavailable, QR falls back to LAN.
- QR authorization is a high-entropy capability link. Anyone who has it can join until `Change QR` or mode change. Share with trusted parties only. No Play Store / unattended installation. No silent Android install/update.
- File history is based on files still present; uninstalling the APK can remove files in app-specific storage. Back up files you want to keep.
- WebRTC remote browser download is buffered in browser memory; for multi-gigabyte files use LAN, or implement streaming File System Access API + resumable transfer before production.

## Development

`bash tests/test-lan.sh` compiles the pure Java LAN server and verifies auth, uploads, duplicates, origin, role, download and traversal protection, and Node validates inline web scripts.

Android build (JDK 17 / Gradle 8.11.1 / Android SDK 35): `gradle -p xstage-file-share assembleRelease` (from repository root after unpacking).

## Publishing and signing

Preview builds use a committed **public test key** to permit same-signer preview updates. This key is insecure for production. Production CI must supply `XSTAGE_FILE_SHARE_KEYSTORE_BASE64`, `XSTAGE_FILE_SHARE_STORE_PASSWORD`, `XSTAGE_FILE_SHARE_KEY_ALIAS`, and `XSTAGE_FILE_SHARE_KEY_PASSWORD`. Production signing will not silently preserve installed previews: Android requires uninstall when signer changes.

This project does not modify Android TV Karaoke, Mirror TV or Song Studio. The `file-share/index.html` hosted page must be available on GitHub Pages for Internet sessions.

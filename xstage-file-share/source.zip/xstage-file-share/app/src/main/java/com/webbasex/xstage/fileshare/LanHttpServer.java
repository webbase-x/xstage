package com.webbasex.xstage.fileshare;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;

/** Local-network HTTP file service. No Android dependencies: can be smoke-tested with a JDK. */
public final class LanHttpServer implements AutoCloseable {
    public interface Listener { void onReceived(String filename, String peer); }
    public enum Mode { RECEIVE, SEND }

    private final Path receiveDir, sendDir;
    private final byte[] portal;
    private final Listener listener;
    private final SecureRandom random = new SecureRandom();
    private final Map<String, Long> sessions = new ConcurrentHashMap<>();
    private final ThreadPoolExecutor clients = new ThreadPoolExecutor(4, 24, 30,
            TimeUnit.SECONDS, new ArrayBlockingQueue<>(80), r -> {
        Thread t = new Thread(r, "xstage-lan-client"); t.setDaemon(true); return t;
    });
    private final Semaphore activeUploads = new Semaphore(6);
    private final Object fileLock = new Object();
    private volatile Mode mode = Mode.RECEIVE;
    private volatile String connectKey = newToken();
    private volatile boolean running;
    private ServerSocket server;
    private Thread acceptThread;

    public LanHttpServer(Path receiveDir, Path sendDir, String portalHtml, Listener listener) throws IOException {
        this.receiveDir = receiveDir;
        this.sendDir = sendDir;
        this.portal = portalHtml.getBytes(StandardCharsets.UTF_8);
        this.listener = listener;
        Files.createDirectories(receiveDir);
        Files.createDirectories(sendDir);
    }

    public synchronized void start() throws IOException {
        if (running) return;
        ServerSocket socket = new ServerSocket();
        socket.setReuseAddress(true);
        try { socket.bind(new InetSocketAddress("0.0.0.0", 8765), 50); }
        catch (BindException conflict) { socket.bind(new InetSocketAddress("0.0.0.0", 0), 50); }
        server = socket;
        running = true;
        acceptThread = new Thread(this::acceptLoop, "xstage-lan-listener");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public int port() { return server == null ? 0 : server.getLocalPort(); }
    public Mode mode() { return mode; }
    public int pairedDeviceCount() { return sessions.size(); }
    public String connectionUrl(String ipv4) {
        if (ipv4 == null || port() == 0) return null;
        return "http://" + ipv4 + ":" + port() + "/connect?key=" + connectKey;
    }

    /** Role changes revoke browser cookies and issue a new QR to avoid stale access. */
    public void setMode(Mode newMode) {
        mode = Objects.requireNonNull(newMode);
        regeneratePairing();
    }
    public void regeneratePairing() {
        connectKey = newToken();
        sessions.clear();
    }

    public List<Path> savedFiles(Mode forMode) {
        Path dir = forMode == Mode.RECEIVE ? receiveDir : sendDir;
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> paths = Files.newDirectoryStream(dir)) {
            for (Path p : paths) if (Files.isRegularFile(p) && !p.getFileName().toString().startsWith(".")) result.add(p);
        } catch (IOException ignored) { }
        result.sort((a, b) -> {
            try { return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a)); }
            catch (IOException ignored) { return 0; }
        });
        return result;
    }

    private String newToken() {
        byte[] bytes = new byte[24]; random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
    private void acceptLoop() {
        while (running) {
            try {
                Socket socket = server.accept();
                socket.setSoTimeout(90000);
                try { clients.execute(() -> handle(socket)); }
                catch (RejectedExecutionException crowded) { socket.close(); }
            } catch (IOException error) { if (running) { /* next accept or close */ } }
        }
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (int i = 0; i < 16384; i++) {
            int c = in.read();
            if (c == -1) return out.size() == 0 ? null : out.toString("ISO-8859-1");
            if (c == '\n') {
                byte[] b = out.toByteArray();
                int n = b.length > 0 && b[b.length - 1] == '\r' ? b.length - 1 : b.length;
                return new String(b, 0, n, StandardCharsets.ISO_8859_1);
            }
            out.write(c);
        }
        throw new IOException("Header line too long");
    }
    private static String param(String target, String key) {
        int i = target.indexOf('?'); if (i < 0) return null;
        for (String part : target.substring(i + 1).split("&")) {
            String[] pair = part.split("=", 2);
            if (pair[0].equals(key)) {
                try { return URLDecoder.decode(pair.length == 2 ? pair[1] : "", "UTF-8"); }
                catch (Exception ignored) { return null; }
            }
        }
        return null;
    }
    private static String header(Map<String,String> h, String name) { return h.getOrDefault(name, ""); }
    private static String sanitizeFilename(String supplied) {
        if (supplied == null) return "file";
        String s;
        try { s = URLDecoder.decode(supplied, "UTF-8"); }
        catch (Exception ignored) { s = supplied; }
        s = s.replace('\\', '/');
        s = s.substring(s.lastIndexOf('/') + 1);
        s = s.replaceAll("[\\p{Cntrl}<>:\"/\\\\|?*]", "_").trim();
        while (s.startsWith(".")) s = s.substring(1);
        if (s.length() > 180) s = s.substring(0, 180);
        return s.isEmpty() ? "file" : s;
    }
    private static String jsonEscape(String value) {
        StringBuilder s = new StringBuilder("\"");
        for (char c : value.toCharArray()) {
            switch (c) {
                case '\\': s.append("\\\\"); break;
                case '"': s.append("\\\""); break;
                case '\n': s.append("\\n"); break;
                case '\r': s.append("\\r"); break;
                case '\t': s.append("\\t"); break;
                default: if (c < 32) s.append(String.format(Locale.US, "\\u%04x", (int)c)); else s.append(c);
            }
        }
        return s.append('"').toString();
    }
    private static void response(OutputStream out, int status, String contentType, byte[] data, String headers) throws IOException {
        String reason = status == 200 ? "OK" : status == 302 ? "Found" : status == 400 ? "Bad Request"
                : status == 401 ? "Unauthorized" : status == 403 ? "Forbidden" : status == 404 ? "Not Found"
                : status == 409 ? "Conflict" : status == 411 ? "Length Required" : status == 413 ? "Content Too Large"
                : status == 503 ? "Service Unavailable" : "Error";
        String head = "HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: " + contentType
                + "\r\nContent-Length: " + data.length + "\r\nConnection: close\r\nCache-Control: no-store"
                + "\r\nX-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\nReferrer-Policy: no-referrer"
                + "\r\n" + headers + "\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        out.write(data);
        out.flush();
    }
    private static void text(OutputStream out, int status, String body) throws IOException {
        response(out, status, "text/plain; charset=utf-8", body.getBytes(StandardCharsets.UTF_8), "");
    }
    private boolean authenticated(Map<String,String> headers) {
        String cookie = header(headers, "cookie");
        for (String part : cookie.split(";")) {
            String t = part.trim();
            if (!t.startsWith("xs_session=")) continue;
            String session = t.substring("xs_session=".length());
            Long time = sessions.get(session);
            return time != null && System.currentTimeMillis() - time < 12L * 3600 * 1000;
        }
        return false;
    }

    private void handle(Socket socket) {
        try (Socket s = socket; InputStream in = new BufferedInputStream(s.getInputStream()); OutputStream out = s.getOutputStream()) {
            String line = readLine(in);
            if (line == null) return;
            String[] request = line.split(" ");
            if (request.length != 3 || !request[2].startsWith("HTTP/1.")) { text(out, 400, "Invalid request"); return; }
            String method = request[0], target = request[1];
            if (!target.startsWith("/") || target.length() > 4096) { text(out, 400, "Invalid path"); return; }
            Map<String,String> headers = new HashMap<>();
            for (int i = 0; i < 80; i++) {
                String row = readLine(in);
                if (row == null) return;
                if (row.isEmpty()) break;
                int colon = row.indexOf(':');
                if (colon > 0) headers.put(row.substring(0, colon).trim().toLowerCase(Locale.ROOT), row.substring(colon + 1).trim());
                if (i == 79) { text(out, 400, "Too many headers"); return; }
            }
            String path = target.split("\\?",2)[0];
            if (method.equals("GET") && path.equals("/connect")) {
                if (!Objects.equals(connectKey, param(target, "key"))) { text(out, 403, "Invalid QR code. Refresh pairing on Android."); return; }
                sessions.entrySet().removeIf(e -> System.currentTimeMillis() - e.getValue() > 12L * 3600 * 1000);
                if (sessions.size() >= 128) { text(out, 503, "Too many paired sessions"); return; }
                String session = newToken();
                sessions.put(session, System.currentTimeMillis());
                response(out, 302, "text/plain; charset=utf-8", new byte[0],
                        "Set-Cookie: xs_session=" + session + "; Path=/; HttpOnly; SameSite=Strict\r\nLocation: /\r\n");
                return;
            }
            if (!authenticated(headers)) { text(out, 401, "Scan the current X-Stage File Share QR to connect."); return; }
            if (method.equals("GET") && path.equals("/")) {
                response(out, 200, "text/html; charset=utf-8", portal,
                        "Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'self'\r\n");
            } else if (method.equals("GET") && path.equals("/api/state")) {
                response(out, 200, "application/json; charset=utf-8", stateJson().getBytes(StandardCharsets.UTF_8), "");
            } else if (method.equals("POST") && path.equals("/api/upload")) {
                if (mode != Mode.RECEIVE) { text(out, 409, "Android is in Send mode"); return; }
                String origin = header(headers, "origin"), host = header(headers, "host");
                if (host.isEmpty() || !origin.equals("http://" + host)) { text(out, 403, "Invalid origin"); return; }
                receiveFile(in, out, header(headers, "x-file-name"), header(headers, "content-length"), s.getInetAddress().getHostAddress());
            } else if (method.equals("GET") && path.equals("/download")) {
                if (mode != Mode.SEND) { text(out, 409, "Android is in Receive mode"); return; }
                sendFile(out, param(target, "name"));
            } else { text(out, 404, "Not found"); }
        } catch (Exception ignored) { /* closed client, cancelled upload, or unsafe request */ }
    }

    public String stateJson() {
        StringBuilder json = new StringBuilder("{\"mode\":\"").append(mode == Mode.RECEIVE ? "receive" : "send").append("\",\"files\":[");
        for (Path p : savedFiles(mode)) {
            if (json.charAt(json.length() - 1) != '[') json.append(',');
            try {
                json.append("{\"name\":").append(jsonEscape(p.getFileName().toString()))
                    .append(",\"bytes\":").append(Files.size(p))
                    .append(",\"modified\":").append(Files.getLastModifiedTime(p).toMillis()).append('}');
            } catch (IOException ignored) { }
        }
        return json.append("]}").toString();
    }
    private static Path uniquePath(Path directory, String filename) {
        Path dest = directory.resolve(filename);
        int dot = filename.lastIndexOf('.');
        String stem = dot > 0 ? filename.substring(0, dot) : filename;
        String ext = dot > 0 ? filename.substring(dot) : "";
        for (int counter = 1; Files.exists(dest); counter++) dest = directory.resolve(stem + " (" + counter + ")" + ext);
        return dest;
    }
    private void receiveFile(InputStream in, OutputStream out, String suppliedName, String declaredLength, String peer) throws IOException {
        long remaining;
        try { remaining = Long.parseLong(declaredLength); }
        catch (Exception invalid) { text(out, 411, "Content-Length required"); return; }
        if (remaining < 0) { text(out, 400, "Invalid length"); return; }
        if (remaining > receiveDir.toFile().getUsableSpace() - 8L * 1024 * 1024) { text(out, 413, "Not enough free storage"); return; }
        try {
            if (!activeUploads.tryAcquire(30, TimeUnit.SECONDS)) { text(out, 503, "Receiver is busy"); return; }
        } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); text(out, 503, "Interrupted"); return; }
        Path pending = null;
        try {
            pending = Files.createTempFile(receiveDir, ".xstage-incoming-", ".part");
            try (OutputStream file = new BufferedOutputStream(Files.newOutputStream(pending))) {
                byte[] buffer = new byte[65536];
                while (remaining > 0) {
                    int read = in.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                    if (read < 0) throw new EOFException("Upload ended early");
                    file.write(buffer, 0, read);
                    remaining -= read;
                }
            }
            String filename = sanitizeFilename(suppliedName);
            Path saved;
            synchronized (fileLock) {
                saved = uniquePath(receiveDir, filename);
                Files.move(pending, saved);
            }
            pending = null;
            text(out, 200, saved.getFileName().toString());
            if (listener != null) listener.onReceived(saved.getFileName().toString(), peer);
        } finally {
            if (pending != null) Files.deleteIfExists(pending);
            activeUploads.release();
        }
    }
    private void sendFile(OutputStream out, String rawName) throws IOException {
        if (rawName == null || !sanitizeFilename(rawName).equals(rawName)) { text(out, 400, "Invalid filename"); return; }
        Path file = sendDir.resolve(rawName).normalize();
        if (!file.getParent().equals(sendDir.normalize()) || !Files.isRegularFile(file)) { text(out, 404, "Not found"); return; }
        long length = Files.size(file);
        String disposition = "attachment; filename*=UTF-8''" + URLEncoder.encode(rawName, "UTF-8").replace("+", "%20");
        String head = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: " + length
                + "\r\nContent-Disposition: " + disposition + "\r\nConnection: close\r\nCache-Control: no-store"
                + "\r\nX-Content-Type-Options: nosniff\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        try (InputStream fileIn = new BufferedInputStream(Files.newInputStream(file))) {
            byte[] buffer = new byte[65536]; int read;
            while ((read = fileIn.read(buffer)) != -1) out.write(buffer, 0, read);
        }
        out.flush();
    }
    @Override public synchronized void close() {
        running = false;
        sessions.clear();
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        clients.shutdownNow();
    }
}

package com.webbasex.xstage.fileshare;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.Locale;
import javax.net.ssl.HttpsURLConnection;

/** Optional HTTPS update check and verified APK installer; Android always approves installation. */
final class UpdateManager {
    private static final String MANIFEST = "https://webbase-x.github.io/xstage/downloads/file-share-latest.json";
    private static final String PREFS = "fileshare_updates";
    private static long lastCheck = 0L;
    private static int promptedBuild = -1;
    private static boolean downloading = false;
    private static File installerPending = null;

    private UpdateManager() { }

    static int installedCode(Activity a) {
        try {
            android.content.pm.PackageInfo p = a.getPackageManager().getPackageInfo(a.getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) return (int)p.getLongVersionCode();
            return p.versionCode;
        } catch (Exception e) { return -1; }
    }

    static void cleanupAfterUpgrade(Activity a) {
        int installed = installedCode(a);
        android.content.SharedPreferences prefs = a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE);
        int target = prefs.getInt("pending_build", 0);
        if (target > 0 && installed >= target) {
            File stale = updatePath(a);
            if (stale.exists()) stale.delete();
            prefs.edit().remove("pending_build").apply();
        }
    }

    static void check(Activity a, boolean manual) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (!manual && now - lastCheck < 10 * 60 * 1000L && lastCheck != 0) return;
        lastCheck = now;
        new Thread(() -> {
            try {
                URL url = new URL(MANIFEST + "?v=" + System.currentTimeMillis());
                HttpsURLConnection c = (HttpsURLConnection) url.openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                c.setRequestProperty("Cache-Control", "no-cache");
                StringBuilder text = new StringBuilder();
                try {
                    if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
                    try (InputStream in = c.getInputStream()) {
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                        byte[] bytes = new byte[4096]; int n;
                        while ((n = in.read(bytes)) != -1) {
                            if (buffer.size() + n > 16384) throw new IOException("Manifest too large");
                            buffer.write(bytes, 0, n);
                        }
                        text.append(buffer.toString("UTF-8"));
                    }
                } finally { c.disconnect(); }
                JSONObject j = new JSONObject(text.toString());
                int code = j.optInt("build_code", 0);
                String version = j.optString("version", "");
                String link = j.optString("download_url", "");
                String sha256 = j.optString("sha256", "");
                if (!j.optBoolean("available", false) || code < 1 || code <= installedCode(a)) {
                    if (manual) a.runOnUiThread(() -> Toast.makeText(a, "ใช้ X-Stage File Share รุ่นล่าสุดแล้ว", Toast.LENGTH_LONG).show());
                    return;
                }
                if (!link.startsWith("https://github.com/webbase-x/xstage/releases/download/") ||
                        !link.endsWith(".apk") || !sha256.matches("[a-fA-F0-9]{64}"))
                    throw new IOException("ข้อมูลอัปเดตไม่ผ่านการตรวจสอบ");
                a.runOnUiThread(() -> {
                    if (a.isFinishing() || a.isDestroyed()) return;
                    if (!manual && promptedBuild == code) return;
                    promptedBuild = code;
                    new AlertDialog.Builder(a).setTitle("พบ X-Stage File Share รุ่นใหม่")
                        .setMessage("รุ่นที่มี: " + version + "\nสามารถดาวน์โหลดและยืนยันการติดตั้งผ่าน Android ได้")
                        .setPositiveButton("ดาวน์โหลดและติดตั้ง", (d, w) -> download(a, link, sha256, code))
                        .setNegativeButton("ภายหลัง", null).show();
                });
            } catch (Exception e) {
                if (manual) a.runOnUiThread(() -> Toast.makeText(a,
                    "ตรวจอัปเดตไม่สำเร็จ โปรดตรวจสอบอินเทอร์เน็ต", Toast.LENGTH_LONG).show());
            }
        }, "XStageFileShare-UpdateCheck").start();
    }

    private static File updatePath(Activity a) {
        File external = a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File root = new File(external != null ? external : a.getFilesDir(), "XStageFileShare/updates");
        return new File(root, "X-Stage-File-Share-update.apk");
    }

    private static synchronized boolean beginDownload() {
        if (downloading) return false;
        downloading = true;
        return true;
    }

    private static void download(Activity a, String link, String sha256, int code) {
        if (!beginDownload()) return;
        Toast.makeText(a, "กำลังดาวน์โหลด APK ที่ตรวจสอบความถูกต้อง", Toast.LENGTH_LONG).show();
        new Thread(() -> {
            File temp = null;
            try {
                File out = updatePath(a);
                if (!out.getParentFile().exists() && !out.getParentFile().mkdirs())
                    throw new IOException("Cannot prepare update directory");
                temp = new File(out.getParentFile(), "download.part");
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                URL url = new URL(link);
                HttpsURLConnection c = (HttpsURLConnection) url.openConnection();
                c.setConnectTimeout(12000); c.setReadTimeout(30000);
                long total = 0;
                try {
                    if (c.getResponseCode() != 200) throw new IOException("Download HTTP " + c.getResponseCode());
                    try (InputStream in = c.getInputStream(); OutputStream target = new BufferedOutputStream(new FileOutputStream(temp))) {
                        byte[] bytes = new byte[65536]; int n;
                        while ((n = in.read(bytes)) != -1) {
                            total += n;
                            if (total > 300L * 1024 * 1024) throw new IOException("APK too large");
                            target.write(bytes, 0, n);
                            digest.update(bytes, 0, n);
                        }
                    }
                } finally { c.disconnect(); }
                if (total < 1024) throw new IOException("Incomplete APK");
                StringBuilder actual = new StringBuilder();
                for (byte x : digest.digest()) actual.append(String.format(Locale.US, "%02x", x & 0xff));
                if (!actual.toString().equalsIgnoreCase(sha256)) throw new SecurityException("APK SHA-256 mismatch");
                if (out.exists() && !out.delete()) throw new IOException("Old APK is locked");
                if (!temp.renameTo(out)) throw new IOException("Cannot move verified APK");
                a.getSharedPreferences(PREFS, Activity.MODE_PRIVATE).edit().putInt("pending_build", code).apply();
                installerPending = out;
                a.runOnUiThread(() -> install(a, out));
            } catch (Exception e) {
                if (temp != null) temp.delete();
                a.runOnUiThread(() -> Toast.makeText(a,
                    "ดาวน์โหลด/ตรวจสอบ APK ไม่สำเร็จ: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally { synchronized (UpdateManager.class) { downloading = false; } }
        }, "XStageFileShare-UpdateDownload").start();
    }

    static void onResume(Activity a) {
        if (installerPending != null && Build.VERSION.SDK_INT >= 26 &&
                a.getPackageManager().canRequestPackageInstalls()) {
            File f = installerPending; installerPending = null;
            install(a, f);
        }
    }

    private static void install(Activity a, File file) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
                installerPending = file;
                new AlertDialog.Builder(a).setTitle("อนุญาตติดตั้ง APK")
                    .setMessage("Android ต้องอนุญาตติดตั้งจาก X-Stage File Share ก่อน ระบบจะเปิดหน้าการตั้งค่าให้")
                    .setPositiveButton("เปิดการตั้งค่า", (d, w) -> {
                        try { a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:" + a.getPackageName()))); }
                        catch (Exception e) { Toast.makeText(a, "เปิดหน้าการตั้งค่าไม่ได้", Toast.LENGTH_LONG).show(); }
                    }).setNegativeButton("ภายหลัง", null).show();
                return;
            }
            Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".files", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(a, "เปิดตัวติดตั้ง Android ไม่สำเร็จ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}

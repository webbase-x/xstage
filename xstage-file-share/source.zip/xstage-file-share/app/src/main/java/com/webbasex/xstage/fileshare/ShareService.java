package com.webbasex.xstage.fileshare;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Foreground session: stays available for browser clients while users switch apps. */
public final class ShareService extends Service {
    private static final String CHANNEL = "xstage_file_share_active";
    private static final int NOTIFICATION = 5741;
    public static final String STOP = "com.webbasex.xstage.fileshare.STOP";
    public final class LocalBinder extends Binder { public ShareService getService() { return ShareService.this; } }
    private final IBinder binder = new LocalBinder();
    private final ExecutorService copies = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private LanHttpServer server;
    private String error = "";
    private Runnable updateListener;
    private File base;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "X-Stage File Share", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, ShareService.class).setAction(STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ?
                new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = builder.setContentTitle("X-Stage File Share")
                .setContentText("รับ–ส่งไฟล์กับอุปกรณ์อื่น")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "หยุดแชร์", stopPi)
                .setOngoing(true).build();
        startForeground(NOTIFICATION, n);
        File external = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        base = new File(external != null ? external : getFilesDir(), "XStageFileShare");
        try {
            byte[] html;
            try (InputStream in = getAssets().open("portal.html")) { html = readSmall(in); }
            server = new LanHttpServer(new File(base, "received").toPath(),
                    new File(base, "to-send").toPath(),
                    new String(html, StandardCharsets.UTF_8), (file, peer) -> notifyUpdate());
            server.start();
        } catch (Exception e) { error = "เริ่มเซิร์ฟเวอร์ไม่สำเร็จ: " + e.getMessage(); }
    }
    private static byte[] readSmall(InputStream input) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = input.read(buf)) != -1) out.write(buf, 0, n);
        return out.toByteArray();
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return binder; }
    public LanHttpServer server() { return server; }
    public Path storeDir(String folderName) { return new File(base, folderName).toPath(); }
    public String error() { return error; }
    public void setUpdateListener(Runnable listener) { updateListener = listener; }
    private void notifyUpdate() { main.post(() -> { if (updateListener != null) updateListener.run(); }); }

    public void importForSending(List<Uri> selected) {
        if (server == null) return;
        copies.execute(() -> {
            String failure = null;
            for (Uri uri : selected) {
                Path temporary = null;
                try {
                    String name = displayName(uri);
                    Path folder = new File(base, "to-send").toPath();
                    Files.createDirectories(folder);
                    temporary = Files.createTempFile(folder, ".xstage-copy-", ".part");
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         OutputStream out = Files.newOutputStream(temporary)) {
                        if (in == null) throw new FileNotFoundException("ไม่สามารถอ่านไฟล์ที่เลือก");
                        byte[] b = new byte[65536]; int n;
                        while ((n = in.read(b)) != -1) out.write(b, 0, n);
                    }
                    String safeName = cleanName(name);
                    synchronized (this) {
                        Path target = folder.resolve(safeName);
                        int dot = safeName.lastIndexOf('.');
                        String stem = dot > 0 ? safeName.substring(0, dot) : safeName;
                        String ext = dot > 0 ? safeName.substring(dot) : "";
                        int i = 1;
                        while (Files.exists(target)) target = folder.resolve(stem + " (" + i++ + ")" + ext);
                        Files.move(temporary, target);
                    }
                    temporary = null;
                } catch (Exception e) { failure = e.getMessage(); }
                finally { if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { } }
            }
            final String message = failure;
            main.post(() -> { if (message != null) error = "นำเข้าบางไฟล์ไม่สำเร็จ: " + message; notifyUpdate(); });
        });
    }
    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() == null ? "file" : uri.getLastPathSegment();
    }
    private static String cleanName(String name) {
        String s = name.replace('\\', '/'); s = s.substring(s.lastIndexOf('/') + 1)
                .replaceAll("[\\p{Cntrl}<>:\"/\\\\|?*]", "_").trim();
        while (s.startsWith(".")) s = s.substring(1);
        if (s.length() > 180) s = s.substring(0, 180);
        return s.isEmpty() ? "file" : s;
    }
    @Override public void onDestroy() {
        updateListener = null;
        if (server != null) server.close();
        copies.shutdownNow();
        super.onDestroy();
    }
}

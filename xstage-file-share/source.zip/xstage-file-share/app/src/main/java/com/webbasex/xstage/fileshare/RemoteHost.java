package com.webbasex.xstage.fileshare;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Best-effort Internet P2P bridge. Remote content is served from bundled app assets;
 * only PeerJS signaling and STUN use third-party services; bytes flow via WebRTC.
 * Certain NATs require a configured TURN relay and cannot complete without one. */
final class RemoteHost implements AutoCloseable {
    interface Observer { void onChanged(); }
    private final Context context;
    private final ShareService service;
    private final Observer observer;
    private final WebView view;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SecureRandom random = new SecureRandom();
    private final Map<String, Upload> uploads = new ConcurrentHashMap<>();
    private volatile String roomId = "";
    private volatile boolean online;
    private boolean closed;

    private static final class Upload {
        final Path pending;
        final String name;
        final OutputStream out;
        final long expected;
        long count;
        Upload(Path pending, String name, OutputStream out, long expected) {
            this.pending = pending; this.name = name; this.out = out; this.expected = expected;
        }
    }

    RemoteHost(Context context, ShareService service, Observer observer) throws IOException {
        this.context = context; this.service = service; this.observer = observer;
        view = new WebView(context);
        view.setVisibility(View.INVISIBLE);
        view.setLayoutParams(new android.view.ViewGroup.LayoutParams(1, 1));
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setDomStorageEnabled(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebChromeClient(new WebChromeClient());
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return true; }
        });
        view.addJavascriptInterface(new Bridge(), "XStageAndroid");
        reset();
    }
    View view() { return view; }
    boolean isReady() { return online; }
    String joinUrl() { return online ? "https://webbase-x.github.io/xstage/file-share/#connect=" + roomId : null; }
    void reset() throws IOException {
        online = false;
        byte[] b = new byte[24]; random.nextBytes(b);
        roomId = "xstage-" + Base64.encodeToString(b, Base64.NO_WRAP | Base64.URL_SAFE | Base64.NO_PADDING);
        for (String token : new ArrayList<>(uploads.keySet())) abort(token);
        String html;
        try (InputStream in = context.getAssets().open("remote.html")) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream(); byte[] chunk = new byte[8192]; int n;
            while ((n = in.read(chunk)) != -1) bytes.write(chunk, 0, n);
            html = bytes.toString("UTF-8");
        }
        view.loadDataWithBaseURL("https://webbase-x.github.io/xstage/file-share/#host=" + roomId, html,
                "text/html", "UTF-8", null);
        observer.onChanged();
    }
    private Path dir(String part) { return service.storeDir(part); }
    private static String safe(String name) {
        if (name == null) return "file";
        String s = name.replace('\\', '/'); s = s.substring(s.lastIndexOf('/') + 1);
        s = s.replaceAll("[\\p{Cntrl}<>:\"/\\\\|?*]", "_").trim();
        while (s.startsWith(".")) s = s.substring(1);
        if (s.length() > 180) s = s.substring(0, 180);
        return s.isEmpty() ? "file" : s;
    }
    private String randomToken() {
        byte[] b = new byte[24]; random.nextBytes(b);
        return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
    }
    private void abort(String token) {
        Upload u = uploads.remove(token);
        if (u != null) {
            service.reportTransfer(u.name, "Internet", u.count, u.expected, "failed");
            try { u.out.close(); } catch (IOException ignored) { }
            try { Files.deleteIfExists(u.pending); } catch (IOException ignored) { }
        }
    }
    private final class Bridge {
        @JavascriptInterface public void status(String id, String state) {
            if (!id.equals(roomId) || closed) return;
            boolean ready = "ready".equals(state);
            if (online != ready) {
                online = ready;
                main.post(observer::onChanged);
            }
        }
        @JavascriptInterface public String version() {
            try { return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName; }
            catch (Exception ignored) { return "unknown"; }
        }
        @JavascriptInterface public String state() {
            LanHttpServer srv = service.server();
            if (srv == null) return "{\"mode\":\"receive\",\"files\":[]}";
            return srv.stateJson();
        }
        @JavascriptInterface public String start(String name, String bytes) {
            LanHttpServer server = service.server();
            if (server == null) return "!NOT_READY";
            if (server.mode() != LanHttpServer.Mode.RECEIVE) return "!NOT_RECEIVING";
            final long expected;
            try { expected = Long.parseLong(bytes); }
            catch (Exception e) { return "!INVALID_SIZE"; }
            if (expected < 0) return "!INVALID_SIZE";
            if (uploads.size() >= 6) return "!BUSY";
            try {
                Path folder = dir("received");
                // A new Android installation may not yet have opened the LAN receiver.
                Files.createDirectories(folder);
                long usable = folder.toFile().getUsableSpace();
                long reserve = 8L * 1024 * 1024;
                if (usable <= reserve || expected > usable - reserve) return "!NO_SPACE";
                Path pending = Files.createTempFile(folder, ".xstage-remote-", ".part");
                try {
                    OutputStream stream = new BufferedOutputStream(Files.newOutputStream(pending));
                    String token = randomToken();
                    String cleaned = safe(name);
                    uploads.put(token, new Upload(pending, cleaned, stream, expected));
                    service.reportTransfer(cleaned, "Internet", 0, expected, "receiving");
                    return token;
                } catch (Exception e) {
                    try { Files.deleteIfExists(pending); } catch (IOException ignored) { }
                    return "!STORE_ERROR";
                }
            } catch (Exception e) { return "!STORE_ERROR"; }
        }
        @JavascriptInterface public long append(String token, String b64) {
            Upload u = uploads.get(token); if (u == null) return -1;
            try {
                byte[] b = Base64.decode(b64, Base64.DEFAULT);
                synchronized (u) {
                    if (b.length > 16384 || u.count + b.length > u.expected) { abort(token); return -1; }
                    u.out.write(b); u.count += b.length;
                    service.reportTransfer(u.name, "Internet", u.count, u.expected, "receiving");
                    return u.count;
                }
            } catch (Exception e) { abort(token); return -1; }
        }
        @JavascriptInterface public String finish(String token) {
            Upload u = uploads.remove(token);
            if (u == null) return "";
            try {
                synchronized (u) { u.out.close(); if (u.count != u.expected) throw new IOException("Incomplete file"); }
                Path folder = dir("received"); Path target;
                synchronized (RemoteHost.this) {
                    target = folder.resolve(u.name);
                    int dot = u.name.lastIndexOf('.');
                    String stem = dot > 0 ? u.name.substring(0, dot) : u.name;
                    String ext = dot > 0 ? u.name.substring(dot) : "";
                    for (int n = 1; Files.exists(target); n++) target = folder.resolve(stem + " (" + n + ")" + ext);
                    Files.move(u.pending, target);
                }
                service.reportTransfer(target.getFileName().toString(), "Internet", u.expected, u.expected, "complete");
                main.post(observer::onChanged);
                return target.getFileName().toString();
            } catch (Exception e) {
                service.reportTransfer(u.name, "Internet", u.count, u.expected, "failed");
                try { Files.deleteIfExists(u.pending); } catch (IOException ignored) { }
                return "";
            }
        }
        @JavascriptInterface public void cancel(String token) { abort(token); }
        @JavascriptInterface public String part(String name, long offset) {
            if (service.server() == null || service.server().mode() != LanHttpServer.Mode.SEND || !safe(name).equals(name)) return "";
            Path folder = dir("to-send"); Path file = folder.resolve(name).normalize();
            if (!file.getParent().equals(folder.normalize()) || !Files.isRegularFile(file)) return "";
            try (RandomAccessFile raf = new RandomAccessFile(file.toFile(), "r")) {
                if (offset < 0 || offset > raf.length()) return "";
                raf.seek(offset); byte[] bytes = new byte[(int)Math.min(16384, raf.length() - offset)];
                raf.readFully(bytes);
                return Base64.encodeToString(bytes, Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }
    }
    @Override public void close() {
        closed = true; online = false;
        for (String token : new ArrayList<>(uploads.keySet())) abort(token);
        view.removeJavascriptInterface("XStageAndroid");
        view.destroy();
    }
}

package com.webbasex.xstage.fileshare;

import android.app.Activity;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import android.webkit.MimeTypeMap;
import androidx.core.content.FileProvider;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import java.net.*;
import java.nio.file.*;
import java.util.*;

/** Native remote-friendly Android / Android TV interface; browsers need no companion app. */
public final class MainActivity extends Activity {
    private static final int PICK_FILES = 801;
    private final int navy = Color.rgb(9, 23, 43), panel = Color.rgb(17, 40, 66);
    private final int green = Color.rgb(92, 236, 184), white = Color.WHITE, muted = Color.rgb(177, 199, 218);
    private ShareService service;
    private RemoteHost remoteHost;
    private String remoteError = "";
    private LinearLayout main;
    private boolean bound;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((ShareService.LocalBinder) binder).getService();
            service.setUpdateListener(() -> render());
            bound = true;
            try { remoteHost = new RemoteHost(MainActivity.this, service, () -> render()); }
            catch (Exception err) { remoteError = "Internet P2P ไม่พร้อม: " + err.getMessage(); }
            render();
        }
        @Override public void onServiceDisconnected(ComponentName name) { service = null; bound = false; render(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(new Intent(this, ShareService.class));
        else startService(new Intent(this, ShareService.class));
        bindService(new Intent(this, ShareService.class), connection, Context.BIND_AUTO_CREATE);
        render();
    }
    @Override protected void onResume() { super.onResume(); if (service != null) render(); }
    @Override protected void onDestroy() {
        if (remoteHost != null) { remoteHost.close(); remoteHost = null; }
        if (service != null) service.setUpdateListener(null);
        if (bound) unbindService(connection);
        super.onDestroy();
    }
    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int fill, int border) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(14));
        if (border != 0) g.setStroke(dp(2), border); return g;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size);
        if (bold) t.setTypeface(null, 1);
        t.setIncludeFontPadding(true); t.setPadding(0, dp(4), 0, dp(4)); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private Button button(String s, boolean active, Runnable action) {
        Button b = new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(17);
        b.setTextColor(active ? navy : white);
        StateListDrawable backgrounds = new StateListDrawable();
        backgrounds.addState(new int[]{android.R.attr.state_focused}, bg(green, white));
        backgrounds.addState(new int[]{android.R.attr.state_pressed}, bg(green, white));
        backgrounds.addState(new int[]{}, bg(active ? green : panel, active ? green : Color.rgb(60, 100, 132)));
        b.setBackground(backgrounds); b.setFocusable(true);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void space(LinearLayout l, int height) {
        View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
    private void card(LinearLayout parent, View child) {
        LinearLayout c = column(); c.setPadding(dp(18), dp(16), dp(18), dp(16)); c.setBackground(bg(panel, 0));
        c.addView(child); parent.addView(c, new LinearLayout.LayoutParams(-1, -2));
    }

    private void render() {
        String focusTag = null;
        View focused = getCurrentFocus();
        if (focused != null && focused.getTag() instanceof String) focusTag = (String) focused.getTag();
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(navy);
        LinearLayout root = column(); root.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(root); setContentView(scroll);
        main = root;
        if (remoteHost != null) {
            View background = remoteHost.view();
            if (background.getParent() instanceof android.view.ViewGroup)
                ((android.view.ViewGroup)background.getParent()).removeView(background);
            root.addView(background, new LinearLayout.LayoutParams(1,1));
        }
        root.addView(text("X-Stage File Share", 28, white, true));
        root.addView(text("รับ–ส่งไฟล์ผ่าน LAN และ Internet • ตรวจจับเครือข่ายอัตโนมัติ", 15, muted, false));
        space(root, 18);

        LanHttpServer server = service == null ? null : service.server();
        if (server == null) {
            root.addView(text(service == null ? "กำลังเริ่มต้นแอป..." : service.error(), 18, green, true));
            return;
        }
        boolean receiving = server.mode() == LanHttpServer.Mode.RECEIVE;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean wide = dm.widthPixels / dm.density >= 700 && dm.widthPixels > dm.heightPixels;
        LinearLayout holder = new LinearLayout(this); holder.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        root.addView(holder, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout left = column(); left.setPadding(dp(5), 0, dp(12), 0);
        LinearLayout right = column(); right.setPadding(dp(12), 0, dp(5), 0);
        if (wide) {
            holder.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
            holder.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        } else {
            holder.addView(left, new LinearLayout.LayoutParams(-1, -2));
            space(holder, 20);
            holder.addView(right, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout roles = new LinearLayout(this); roles.setOrientation(LinearLayout.HORIZONTAL);
        Button receive = button("รับไฟล์", receiving, () -> switchMode(server, LanHttpServer.Mode.RECEIVE));
        Button send = button("ส่งไฟล์", !receiving, () -> switchMode(server, LanHttpServer.Mode.SEND));
        receive.setTag("receive"); send.setTag("send");
        roles.addView(receive, new LinearLayout.LayoutParams(0, dp(58), 1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(0, dp(58), 1); sendParams.leftMargin = dp(8);
        roles.addView(send, sendParams); left.addView(roles);
        space(left, 12);
        left.addView(text(receiving ? "● พร้อมรับไฟล์จากอุปกรณ์อื่น" : "● พร้อมให้ดาวน์โหลดจากอุปกรณ์อื่น", 17, green, true));
        left.addView(text("จับคู่แล้ว " + server.pairedDeviceCount() + " เบราว์เซอร์", 14, muted, false));

        String ip = localIpv4();
        String lanUrl = server.connectionUrl(ip);
        String internetUrl = remoteHost == null ? null : remoteHost.joinUrl();
        String url = internetUrl != null ? internetUrl : lanUrl;
        if (url == null) {
            left.addView(text("ยังเชื่อมต่อไม่ได้\nเชื่อมต่อ Wi-Fi / Ethernet หรืออินเทอร์เน็ต แล้วกดรีเฟรช", 16, white, true));
        } else {
            try {
                int pixels = Math.max(180, Math.min(Math.min((int)(dm.widthPixels * (wide ? .30f : .74f)),
                        (int)(dm.heightPixels * .49f)), dp(420)));
                Map<EncodeHintType,Object> hints = new HashMap<>(); hints.put(EncodeHintType.MARGIN, 2);
                BitMatrix qr = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, pixels, pixels, hints);
                int[] colors = new int[pixels * pixels];
                for (int y = 0; y < pixels; y++) for (int x = 0; x < pixels; x++)
                    colors[y * pixels + x] = qr.get(x, y) ? Color.BLACK : Color.WHITE;
                Bitmap bitmap = Bitmap.createBitmap(colors, pixels, pixels, Bitmap.Config.ARGB_8888);
                ImageView view = new ImageView(this); view.setImageBitmap(bitmap);
                view.setBackground(bg(white, 0)); view.setPadding(dp(8), dp(8), dp(8), dp(8));
                LinearLayout.LayoutParams qrParams = new LinearLayout.LayoutParams(pixels + dp(16), pixels + dp(16));
                qrParams.gravity = Gravity.CENTER_HORIZONTAL; qrParams.topMargin = dp(12);
                left.addView(view, qrParams);
            } catch (Exception failure) { left.addView(text("ไม่สามารถสร้าง QR: " + failure.getMessage(), 15, white, false)); }
            TextView address = text((internetUrl != null ? "Internet P2P • สแกน QR ได้จากต่างเครือข่าย\n" : "LAN • สแกน QR ในเครือข่ายเดียวกัน\n")
                   + (internetUrl != null ? internetUrl : ("http://" + ip + ":" + server.port())), 14, white, false);
            address.setGravity(Gravity.CENTER); left.addView(address);
        }
        space(left, 8);
        Button refresh = button("↻ เปลี่ยน QR / ตัดการจับคู่เดิม", false, () -> refreshPairing(server));
        refresh.setTag("refresh"); left.addView(refresh, new LinearLayout.LayoutParams(-1, dp(58)));
        left.addView(text(internetUrl != null
                ? "ระบบเลือกเส้นทาง P2P อัตโนมัติ หากเครือข่ายขวาง WebRTC อาจต้องใช้ TURN Relay; ใช้ LAN โดยตรงได้ที่ " + (lanUrl == null ? "ไม่มี LAN" : lanUrl.split("/connect")[0])
                : "LAN ใช้ได้แม้ไม่มีอินเทอร์เน็ต • Internet P2P จะเปิดให้อัตโนมัติเมื่อบริการจับคู่พร้อม (ต้องมี WebView และอินเทอร์เน็ต)",
                13, muted, false));
        if (!remoteError.isEmpty()) left.addView(text(remoteError, 13, Color.rgb(255,190,135), false));

        LinearLayout files = column();
        files.addView(text(receiving ? "ประวัติไฟล์ที่รับ (ไฟล์ยังอยู่ในเครื่อง)" : "ไฟล์ที่เลือกให้เครื่องอื่นดาวน์โหลด", 20, white, true));
        if (!receiving) {
            Button choose = button("+ เลือกไฟล์ที่ต้องการส่ง", true, this::chooseFiles);
            choose.setTag("choose"); files.addView(choose, new LinearLayout.LayoutParams(-1, dp(58)));
            space(files, 10);
        }
        List<Path> entries = server.savedFiles(server.mode());
        if (entries.isEmpty()) files.addView(text(receiving ? "ยังไม่มีไฟล์ที่ได้รับ" : "ยังไม่มีไฟล์ให้ดาวน์โหลด", 16, muted, false));
        for (Path p : entries) {
            LinearLayout line = new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL);
            long bytes = 0; try { bytes = Files.size(p); } catch (Exception ignored) { }
            TextView name = text(p.getFileName().toString() + "\n" + sizeText(bytes), 15, white, true);
            line.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            Button open = button("เปิด", false, () -> openFile(p));
            open.setTextSize(15); line.addView(open, new LinearLayout.LayoutParams(dp(88), dp(54)));
            files.addView(line); space(files, 8);
        }
        if (!service.error().isEmpty()) files.addView(text(service.error(), 14, Color.rgb(255,190,135), false));
        card(right, files);
        if (focusTag != null) focusNamed(root, focusTag);
    }
    private void switchMode(LanHttpServer server, LanHttpServer.Mode mode) {
        server.setMode(mode);
        if (remoteHost != null) try { remoteHost.reset(); }
        catch (Exception e) { remoteError = "เชื่อมต่อ Internet ไม่สำเร็จ: " + e.getMessage(); }
        render();
    }
    private void refreshPairing(LanHttpServer server) {
        server.regeneratePairing();
        if (remoteHost != null) try { remoteHost.reset(); }
        catch (Exception e) { remoteError = "เชื่อมต่อ Internet ไม่สำเร็จ: " + e.getMessage(); }
        render();
    }
    private void focusNamed(View root, String tag) {
        if (tag.equals(root.getTag())) { root.requestFocus(); return; }
        if (root instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) focusNamed(group.getChildAt(i), tag);
        }
    }
    private static String sizeText(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L*1024) return String.format(Locale.US, "%.1f KB", bytes/1024.0);
        if (bytes < 1024L*1024*1024) return String.format(Locale.US, "%.1f MB", bytes/1048576.0);
        return String.format(Locale.US, "%.2f GB", bytes/1073741824.0);
    }
    private String localIpv4() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if (cm != null) {
            for (Network network : cm.getAllNetworks()) {
                NetworkCapabilities c = cm.getNetworkCapabilities(network);
                if (c == null || !(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) continue;
                LinkProperties lp = cm.getLinkProperties(network);
                if (lp == null) continue;
                for (LinkAddress address : lp.getLinkAddresses()) {
                    InetAddress a = address.getAddress();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
                }
            }
        }
        try {
            Enumeration<NetworkInterface> all = NetworkInterface.getNetworkInterfaces();
            if (all == null) return null;
            List<NetworkInterface> interfaces = Collections.list(all);
            interfaces.sort(Comparator.comparingInt(n -> {
                String name = n.getName().toLowerCase(Locale.ROOT);
                if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("eth")) return 0;
                if (name.startsWith("rmnet") || name.startsWith("tun")) return 9;
                return 4;
            }));
            for (NetworkInterface n : interfaces) {
                if (!n.isUp() || n.isLoopback()) continue;
                String name = n.getName().toLowerCase(Locale.ROOT);
                if (name.startsWith("rmnet") || name.startsWith("tun")) continue;
                for (InetAddress a : Collections.list(n.getInetAddresses()))
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
            }
        } catch (Exception ignored) { }
        return null;
    }
    private void chooseFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(intent, PICK_FILES); }
        catch (Exception e) { Toast.makeText(this, "เครื่องนี้ไม่มีตัวเลือกไฟล์ที่รองรับ", Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null || service == null) return;
        List<Uri> selection = new ArrayList<>();
        if (data.getClipData() != null) for (int i = 0; i < data.getClipData().getItemCount(); i++)
            selection.add(data.getClipData().getItemAt(i).getUri());
        else if (data.getData() != null) selection.add(data.getData());
        if (!selection.isEmpty()) {
            service.importForSending(selection);
            Toast.makeText(this, "กำลังเตรียมไฟล์สำหรับดาวน์โหลด", Toast.LENGTH_SHORT).show();
        }
    }
    private void openFile(Path path) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", path.toFile());
            String name = path.getFileName().toString();
            String ext = MimeTypeMap.getFileExtensionFromUrl(name);
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
            Intent view = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime == null ? "*/*" : mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(view, "เปิดด้วยแอป"));
        } catch (Exception e) { Toast.makeText(this, "ไม่มีแอปที่รองรับการเปิดไฟล์นี้", Toast.LENGTH_LONG).show(); }
    }
}

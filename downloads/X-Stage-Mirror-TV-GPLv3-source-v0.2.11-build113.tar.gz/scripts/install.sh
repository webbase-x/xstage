#!/usr/bin/env bash
# Build and install AirShow on a connected Android TV.
#
# Usage:
#   ./scripts/install.sh                  # build armeabi-v7a debug and install
#   ./scripts/install.sh arm64-v8a        # build for a 64-bit device
#   ./scripts/install.sh --install-only   # install the last built APK
set -euo pipefail

cd "$(dirname "$0")/.."

ADB="${ADB:-adb}"
ABI="${1:-armeabi-v7a}"
APK="app/build/outputs/apk/debug/app-debug.apk"

if [[ "${1:-}" == "--install-only" ]]; then
  shift
  APK="${1:-$APK}"
else
  ./gradlew :app:assembleDebug "-Pabis=${ABI}"
fi

if ! "$ADB" get-state >/dev/null 2>&1; then
  echo "No ADB device. For a TV on the same network:" >&2
  echo "  adb connect <tv-ip>:5555" >&2
  exit 1
fi

"$ADB" install -r "$APK"
"$ADB" shell am start -n app.airshow.tv/.MainActivity
echo "AirShow installed and launched."

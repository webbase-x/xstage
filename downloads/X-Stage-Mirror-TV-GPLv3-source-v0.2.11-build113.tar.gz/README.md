# AirShow

[![Build](https://github.com/omerekelly/airshow/actions/workflows/build.yml/badge.svg)](https://github.com/omerekelly/airshow/actions/workflows/build.yml)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](LICENSE)

**AirShow turns your Android TV into an AirPlay display.** Mirror your Mac, iPhone, or iPad screen to the big screen with no dongle, no account, and no cloud.

AirShow is a free, open-source AirPlay 2 receiver for Android TV, built on the excellent [UxPlay](https://github.com/FDH2/UxPlay) protocol implementation. It is a fork of [jqssun/android-airplay-server](https://github.com/jqssun/android-airplay-server), rebranded and tuned for the living room.

![AirShow running on Android TV](docs/airshow-tv.png)

![AirShow banner](branding/airshow-banner.png)

## Features

- **Screen mirroring** from macOS, iOS, and iPadOS (H.264 / HEVC)
- **Audio streaming** with AAC-ELD, AAC-LC, and ALAC
- **AirPlay video** playback with HLS, seeking, and remote-control support
- **Android TV native**: D-pad navigation, leanback launcher banner, 10-foot UI
- **Low latency** hardware decoding through `MediaCodec`, with software fallback
- **Background receiver** with optional start-on-boot
- **Optional PIN** for each connection
- **No tracking, no ads, no accounts**

> DRM-protected content (for example, the Apple TV app) is not supported.

Tested on a Xiaomi Mi TV (MiTV-AFKR0, Android 11, armeabi-v7a) with macOS and
iOS senders.

## Install

### On a Xiaomi Mi TV / Android TV

1. Enable **Developer options → USB debugging** (and **Network debugging** where available) on the TV.
2. Connect over ADB:

   ```bash
   adb connect <tv-ip>:5555
   adb install -r airshow.apk
   ```

3. Open **AirShow** from the Android TV launcher.

### From source

Requirements: JDK 17, Android SDK with API 37, NDK 28.2, CMake 3.22.

```bash
git submodule update --init --recursive
./gradlew :app:assembleDebug -Pabis=armeabi-v7a   # or arm64-v8a for modern boxes
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Omit `-Pabis` to build all supported ABIs.

### Release build

Create a signing key once and point `local.properties` at it (the file is
git-ignored):

```bash
keytool -genkeypair -keystore ~/.airshow/airshow-release.jks -alias airshow \
  -keyalg RSA -keysize 2048 -validity 10000

cat >> local.properties <<'EOF'
storeFile=/Users/you/.airshow/airshow-release.jks
storePassword=...
keyAlias=airshow
keyPassword=...
EOF

./gradlew :app:assembleRelease -Pabis=armeabi-v7a
```

The APK is written to `app/build/outputs/apk/release/app-release.apk`.

## Use

1. Start AirShow on the TV. The receiver advertises itself on the local network as **AirShow** (configurable in Settings).
2. On your Mac, open **Control Center → Screen Mirroring** and pick AirShow.
3. On your iPhone or iPad, open **Control Center → Screen Mirroring** and pick AirShow.
4. To stream music, pick AirShow from the AirPlay output menu in Apple Music or any AirPlay-compatible app.

The server can be configured over ADB on headless devices:

```bash
adb shell am broadcast -n app.airshow.tv/.SettingsReceiver \
  -a app.airshow.tv.SET_SETTING --es key server_name --es value "Living Room"
```

## Architecture

```
Apple device ── AirPlay/RAOP ──▶ UxPlay (C, JNI)
                                   │
                                   ├── H.264/HEVC ──▶ MediaCodec ──▶ SurfaceView
                                   ├── AAC/ALAC ────▶ MediaCodec/AudioTrack
                                   └── HLS ─────────▶ ExoPlayer
```

- `app/src/main/cpp` — JNI bridge, mDNS shim, audio engine, UxPlay integration
- `app/src/main/kotlin` — Compose UI, foreground service, discovery, decoding, playback
- `branding/make_assets.py` — reproducible icon and TV banner generation

## Credits

AirShow stands on the shoulders of open-source projects:

- [UxPlay](https://github.com/FDH2/UxPlay) — AirPlay/RAOP protocol implementation
- [jqssun/android-airplay-server](https://github.com/jqssun/android-airplay-server) — Android JNI port this project is forked from
- [RPiPlay](https://github.com/FD-/RPiPlay), [shairplay](https://github.com/juhovh/shairplay), and [playfair](https://github.com/tsowell/playfair) — protocol predecessors
- [FFmpeg](https://ffmpeg.org) — lossless audio decoding
- [Next Player](https://github.com/anilbeesetti/nextplayer) — video player inspiration
- [Oboe](https://github.com/google/oboe) — low-latency audio

## License

AirShow is licensed under the **GNU General Public License v3.0**. See [LICENSE](LICENSE) and [NOTICE](NOTICE).

AirShow is not affiliated with, endorsed by, or sponsored by Apple Inc. AirPlay is a trademark of Apple Inc.

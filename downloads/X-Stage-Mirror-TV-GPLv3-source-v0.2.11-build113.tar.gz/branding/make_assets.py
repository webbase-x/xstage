#!/usr/bin/env python3
"""Generate AirShow launcher icon and Android TV banner.

Requires Pillow. Run from the repository root:
    python3 branding/make_assets.py
"""
from __future__ import annotations

import math
import os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "app", "src", "main", "res")
BRAND = os.path.join(ROOT, "branding")

BG_TOP = (7, 10, 18)
BG_BOTTOM = (13, 21, 38)
INK = (14, 22, 38)
CORAL = (255, 90, 110)
AMBER = (255, 176, 90)
CYAN = (90, 209, 255)
WHITE = (246, 249, 255)
MUTED = (143, 163, 196)

FONT_BLACK = "/System/Library/Fonts/Supplemental/Arial Black.ttf"
FONT_BOLD = "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
FONT_REGULAR = "/System/Library/Fonts/Supplemental/Arial.ttf"


def vertical_gradient(size, top, bottom):
    w, h = size
    img = Image.new("RGB", (1, h))
    px = img.load()
    for y in range(h):
        t = y / max(1, h - 1)
        px[0, y] = tuple(round(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
    return img.resize((w, h), Image.BILINEAR)


def add_glow(img, center, radius, color, strength=90):
    """Soft radial glow composited onto an RGB image."""
    from PIL import ImageChops

    layer = Image.new("RGB", img.size, (0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 28
    for i in range(steps, 0, -1):
        r = radius * i / steps
        a = strength * (1 - i / steps) ** 2
        c = tuple(round(color[j] * a / 255) for j in range(3))
        d.ellipse((center[0] - r, center[1] - r, center[0] + r, center[1] + r), fill=c)
    return ImageChops.add(img, layer)


def draw_mark(draw, x, y, s, stroke=True, screen=True):
    """Draw the AirShow mark in a box of size s at (x, y)."""
    # screen
    pad = s * 0.10
    sx0, sy0 = x + pad, y + s * 0.14
    sx1, sy1 = x + s - pad, y + s * 0.66
    radius = s * 0.075
    if screen:
        draw.rounded_rectangle((sx0, sy0, sx1, sy1), radius=radius, fill=INK)
    draw.rounded_rectangle(
        (sx0, sy0, sx1, sy1), radius=radius, outline=CORAL, width=max(2, round(s * 0.028))
    )
    # play triangle
    cx, cy = (sx0 + sx1) / 2, (sy0 + sy1) / 2
    t = s * 0.135
    draw.polygon(
        [(cx - t * 0.62, cy - t), (cx - t * 0.62, cy + t), (cx + t * 1.05, cy)],
        fill=AMBER,
    )
    # stand
    sw = s * 0.10
    draw.rounded_rectangle(
        (x + s / 2 - sw / 2, sy1, x + s / 2 + sw / 2, sy1 + s * 0.075),
        radius=s * 0.015,
        fill=CORAL,
    )
    bw = s * 0.30
    draw.rounded_rectangle(
        (x + s / 2 - bw / 2, sy1 + s * 0.075, x + s / 2 + bw / 2, sy1 + s * 0.115),
        radius=s * 0.02,
        fill=CORAL,
    )
    # air waves, bottom-left
    acx, acy = x + s * 0.20, y + s * 0.80
    for i, r in enumerate((s * 0.08, s * 0.14, s * 0.20)):
        w = max(2, round(s * 0.022))
        draw.arc(
            (acx - r, acy - r, acx + r, acy + r),
            start=270,
            end=360,
            fill=CYAN if i < 2 else AMBER,
            width=w,
        )


def make_icon(size=512):
    img = vertical_gradient((size, size), BG_TOP, (18, 28, 48))
    d = ImageDraw.Draw(img)
    # center the mark, leaving launcher safe space
    s = size * 0.66
    draw_mark(d, (size - s) / 2, (size - s) / 2 - size * 0.01, s)
    return img


def make_foreground(size=432):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    s = size * 0.60
    draw_mark(d, (size - s) / 2, (size - s) / 2, s)
    return img


def make_banner(w=1280, h=720):
    img = vertical_gradient((w, h), BG_TOP, BG_BOTTOM)
    img = add_glow(img, (int(w * 0.08), int(h * 0.95)), int(h * 0.85), CORAL, 55)
    img = add_glow(img, (int(w * 0.92), int(h * 0.05)), int(h * 0.75), CYAN, 32)
    d = ImageDraw.Draw(img)

    # subtle grid dots
    for gx in range(0, w, 48):
        for gy in range(0, h, 48):
            d.point((gx, gy), fill=(255, 255, 255, 10))

    # mark
    mark_size = int(h * 0.56)
    mark_x = int(w * 0.055)
    mark_y = int((h - mark_size) * 0.46)
    draw_mark(d, mark_x, mark_y, mark_size)

    # wordmark
    text_x = mark_x + mark_size + int(w * 0.045)
    avail = w - text_x - int(w * 0.055)
    tracking = int(h * 0.012)
    title = "AIRSHOW"
    title_size = int(h * 0.185)
    while title_size > 20:
        title_font = ImageFont.truetype(FONT_BLACK, title_size)
        widths = [d.textlength(ch, font=title_font) for ch in title]
        total = sum(widths) + tracking * (len(title) - 1)
        if total <= avail:
            break
        title_size -= 4
    tag_font = ImageFont.truetype(FONT_BOLD, int(h * 0.048))
    ty = int(h * 0.29)

    # gradient-filled title
    mask = Image.new("L", (w, h), 0)
    md = ImageDraw.Draw(mask)
    cx = text_x
    for ch, cw in zip(title, widths):
        md.text((cx, ty), ch, font=title_font, fill=255)
        cx += cw + tracking
    grad = vertical_gradient((w, h), WHITE, (255, 196, 150))
    img = Image.composite(grad, img, mask)
    d = ImageDraw.Draw(img)

    tag = "MIRROR  ·  CAST  ·  SHINE"
    d.text((text_x + 2, ty + int(h * 0.235)), tag, font=tag_font, fill=MUTED)

    # accent bar
    bh = max(4, int(h * 0.009))
    d.rounded_rectangle(
        (text_x + 2, ty + int(h * 0.205), text_x + total * 0.42, ty + int(h * 0.205) + bh),
        radius=bh // 2,
        fill=CORAL,
    )
    return img


def make_mark(size=512):
    """Tightly cropped brand mark for in-app use (transparent background)."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    s = size * 0.94
    draw_mark(d, (size - s) / 2, (size - s) / 2, s)
    return img


def save(img, path, size=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    out = img.resize(size, Image.LANCZOS) if size else img
    out.save(path, optimize=True)
    print("wrote", os.path.relpath(path, ROOT))


def main():
    icon = make_icon(512)
    save(icon, os.path.join(BRAND, "airshow-icon.png"))
    save(icon, os.path.join(BRAND, "airshow-icon-1024.png"), (1024, 1024))

    fg = make_foreground(432)
    save(fg, os.path.join(RES, "drawable-xxxhdpi", "ic_launcher_foreground.png"))
    save(fg, os.path.join(BRAND, "airshow-foreground.png"))

    mark = make_mark(512)
    save(mark, os.path.join(RES, "drawable-xxxhdpi", "airshow_mark.png"))
    save(mark, os.path.join(BRAND, "airshow-mark.png"))

    banner = make_banner()
    save(banner, os.path.join(BRAND, "airshow-banner.png"))
    save(banner, os.path.join(RES, "drawable-xhdpi", "banner.png"), (640, 360))
    save(banner, os.path.join(RES, "drawable", "banner.png"), (320, 180))

    # legacy launcher icons for API < 26
    for dpi, size in {
        "mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192,
    }.items():
        save(icon, os.path.join(RES, f"mipmap-{dpi}", "ic_launcher.png"), (size, size))
        save(icon, os.path.join(RES, f"mipmap-{dpi}", "ic_launcher_round.png"), (size, size))


if __name__ == "__main__":
    main()

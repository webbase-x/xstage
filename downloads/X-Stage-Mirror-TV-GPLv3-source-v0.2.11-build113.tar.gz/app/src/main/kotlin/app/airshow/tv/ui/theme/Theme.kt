package app.airshow.tv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AirShowColors = darkColorScheme(
    primary = Color(0xFF7AE7FF),
    onPrimary = Color(0xFF082A3C),
    primaryContainer = Color(0xFF4A1620),
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = Color(0xFF5AD1FF),
    onSecondary = Color(0xFF06202B),
    secondaryContainer = Color(0xFF0E3444),
    onSecondaryContainer = Color(0xFFC9F0FF),
    tertiary = Color(0xFFFFB05A),
    onTertiary = Color(0xFF2B1704),
    background = Color(0xFF070A12),
    onBackground = Color(0xFFF6F9FF),
    surface = Color(0xFF0B1220),
    onSurface = Color(0xFFF6F9FF),
    surfaceVariant = Color(0xFF16223A),
    onSurfaceVariant = Color(0xFFE1EAF8),
    surfaceDim = Color(0xFF05080F),
    surfaceBright = Color(0xFF1B2740),
    surfaceContainerLowest = Color(0xFF050810),
    surfaceContainerLow = Color(0xFF0A101C),
    surfaceContainer = Color(0xFF0D1526),
    surfaceContainerHigh = Color(0xFF121C30),
    surfaceContainerHighest = Color(0xFF18243B),
    inverseSurface = Color(0xFFF6F9FF),
    inverseOnSurface = Color(0xFF0B1220),
    inversePrimary = Color(0xFF8C1D2C),
    outline = Color(0xFF91A7C7),
    outlineVariant = Color(0xFF1E2C45),
    surfaceTint = Color(0xFF7AE7FF),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
)

@Composable
fun AirShowTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AirShowColors, content = content)
}

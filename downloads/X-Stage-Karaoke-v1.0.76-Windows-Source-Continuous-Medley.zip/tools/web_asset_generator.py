"""Standalone entrypoint; runnable from any current working directory."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from karaoke.offline_generator import main

if __name__ == '__main__':
    raise SystemExit(main())

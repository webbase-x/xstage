package app.airshow.tv.renderer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import android.util.Log
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer

// rate is 0 while buffering; speed is the configured rate regardless of pause state
// native reads the effective rate, overlay reads playWhenReady + speed + skipSilence
data class PlaybackSnapshot(
    val position: Float,
    val duration: Float,
    val rate: Float,
    val ready: Boolean,
    val playWhenReady: Boolean,
    val speed: Float = 1f,
    val skipSilence: Boolean = false,
    val buffering: Boolean = false,
)

// exoplayer calls stay on the main thread; native only reads the onPlaybackInfo snapshot
class AirPlayVideoPlayer(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var pendingSurface: Surface? = null
    private var clientGain = 1f
    // Values are touched only on ExoPlayer's application (main) looper.
    private var bufferingSinceMs = 0L
    private var readySinceMs = 0L
    private var consecutiveRecoveries = 0
    private var lastKnownLive = false

    var onPlaybackInfo: ((PlaybackSnapshot) -> Unit)? = null
    var onVideoSize: ((width: Int, height: Int, aspect: Float) -> Unit)? = null
    var onTitle: ((String?) -> Unit)? = null
    var onEnded: (() -> Unit)? = null

    private val _reportTick = object : Runnable {
        override fun run() {
            _reportPlaybackInfo()
            mainHandler.postDelayed(this, REPORT_INTERVAL_MS)
        }
    }

    // Distinguish transient live HLS stalls from VOD failures. If buffering
    // continues after a bounded interval, restart only the player, preserving
    // the current AirPlay receiver and its screen-mirroring connection.
    private val _stallWatchdog = object : Runnable {
        override fun run() {
            val current = player ?: return
            val now = SystemClock.elapsedRealtime()
            if (current.isCurrentMediaItemLive) lastKnownLive = true
            if (!current.playWhenReady || current.playbackState == Player.STATE_READY) {
                bufferingSinceMs = 0L
                if (current.playbackState == Player.STATE_READY && current.playWhenReady) {
                    if (readySinceMs == 0L) readySinceMs = now
                    if (now - readySinceMs >= STABLE_PLAYBACK_MS) {
                        consecutiveRecoveries = 0
                    }
                } else {
                    readySinceMs = 0L
                }
            } else if (current.playbackState == Player.STATE_BUFFERING ||
                       current.playbackState == Player.STATE_IDLE) {
                readySinceMs = 0L
                if (bufferingSinceMs == 0L) bufferingSinceMs = now
                val timeoutMs = if (lastKnownLive) LIVE_BUFFERING_TIMEOUT_MS
                    else VOD_BUFFERING_TIMEOUT_MS
                if (now - bufferingSinceMs >= timeoutMs) {
                    if (!_recoverOrFinish("buffering timeout")) return
                }
            }
            mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS)
        }
    }

    // On an HLS live stream the old absolute position can fall outside the
    // sliding playlist window; always restart at the current live edge.
    private fun _recoverOrFinish(reason: String): Boolean {
        val current = player ?: return false
        val live = current.isCurrentMediaItemLive || lastKnownLive
        val maxRecoveries = if (live) LIVE_MAX_RECOVERIES else VOD_MAX_RECOVERIES
        if (consecutiveRecoveries >= maxRecoveries) {
            _reportFailure("AirPlay video $reason after $consecutiveRecoveries retries, live=$live")
            return false
        }
        consecutiveRecoveries++
        bufferingSinceMs = SystemClock.elapsedRealtime()
        readySinceMs = 0L
        val previousPosition = current.currentPosition.coerceAtLeast(0L)
        Log.w(TAG, "Recovering AirPlay video ($reason): attempt " +
            "$consecutiveRecoveries/$maxRecoveries, live=$live")
        // Media3 stop + prepare reopens the HTTP/HLS source. A plain prepare()
        // while BUFFERING does not reliably restart a stalled load.
        current.stop()
        if (live) {
            current.seekToDefaultPosition()
        } else {
            current.seekTo(previousPosition)
        }
        current.prepare()
        current.playWhenReady = true
        return true
    }

    private fun _reportFailure(reason: String) {
        Log.w(TAG, reason)
        mainHandler.removeCallbacks(_stallWatchdog)
        Toast.makeText(context,
            "วิดีโอขัดข้องหรือสัญญาณถ่ายทอดสดไม่พร้อม โปรดลองเล่นใหม่",
            Toast.LENGTH_LONG).show()
        onEnded?.invoke()
    }

    private val _listener = object : Player.Listener {
        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            Log.w(TAG, "AirPlay video error: " + error.errorCodeName, error)
            // Avoid stop/prepare re-entry during ExoPlayer listener dispatch.
            val failingPlayer = player
            mainHandler.post {
                if (failingPlayer != null && player === failingPlayer)
                    _recoverOrFinish("player error: " + error.errorCodeName)
            }
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                bufferingSinceMs = 0L
                readySinceMs = SystemClock.elapsedRealtime()
                if (player?.isCurrentMediaItemLive == true) lastKnownLive = true
            }
            if (state == Player.STATE_BUFFERING && bufferingSinceMs == 0L)
                bufferingSinceMs = SystemClock.elapsedRealtime()
            if (state == Player.STATE_ENDED) {
                if (lastKnownLive || player?.isCurrentMediaItemLive == true) {
                    // Sliding live playlists can end after a temporary manifest gap.
                    val endedPlayer = player
                    mainHandler.post {
                        if (endedPlayer != null && player === endedPlayer)
                            _recoverOrFinish("live playlist ended")
                    }
                } else {
                    onEnded?.invoke()
                }
            }
        }
        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            // duration is usually established here (esp. hls): report so the held /play releases
            _reportPlaybackInfo()
        }
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            onTitle?.invoke(mediaMetadata.title?.toString())
        }
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.height == 0) return
            val width = (videoSize.width * videoSize.pixelWidthHeightRatio).toInt()
            onVideoSize?.invoke(width, videoSize.height, width.toFloat() / videoSize.height)
        }
    }

    fun play(location: String, startPositionSeconds: Float) = mainHandler.post {
        // recycling must not report the stopped sentinel: senders poll right after /play
        _stopInternal(reportStopped = false)
        val p = ExoPlayer.Builder(context).build().also {
            it.addListener(_listener)
            pendingSurface?.let { s -> it.setVideoSurface(s) }
            it.volume = clientGain
        }
        player = p
        bufferingSinceMs = SystemClock.elapsedRealtime()
        readySinceMs = 0L
        consecutiveRecoveries = 0
        lastKnownLive = false
        p.setMediaItem(MediaItem.fromUri(location), (startPositionSeconds * 1000).toLong())
        p.playWhenReady = true
        p.prepare()
        onPlaybackInfo?.invoke(PlaybackSnapshot(startPositionSeconds, 0f, 0f, false, true))
        mainHandler.postDelayed(_reportTick, REPORT_INTERVAL_MS)
        mainHandler.postDelayed(_stallWatchdog, WATCHDOG_INTERVAL_MS)
    }

    fun scrub(positionSeconds: Float) = mainHandler.post {
        player?.seekTo((positionSeconds * 1000).toLong())
    }

    // coalesces the seek spam from drag-seeking
    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
    fun setScrubbing(enabled: Boolean) = mainHandler.post {
        player?.isScrubbingModeEnabled = enabled
    }

    fun setRate(rate: Float) = mainHandler.post {
        val p = player ?: return@post
        if (rate <= 0f) {
            p.playWhenReady = false
        } else {
            p.playbackParameters = PlaybackParameters(rate.coerceAtLeast(0.1f))
            p.playWhenReady = true
        }
    }

    // local-only: the sender self-syncs from its next /playback-info poll
    fun setPlaying(playing: Boolean) = mainHandler.post {
        player?.playWhenReady = playing
    }

    // local speed toggle: unlike setRate it must not resume a paused player
    fun setSpeed(speed: Float) = mainHandler.post {
        player?.playbackParameters = PlaybackParameters(speed.coerceAtLeast(0.1f))
    }

    // linear, unity unless sender volume isn't synced to receiver
    fun setClientGain(gain: Float) = mainHandler.post {
        clientGain = gain
        player?.volume = gain
    }

    fun setSkipSilence(enabled: Boolean) = mainHandler.post {
        player?.skipSilenceEnabled = enabled
    }

    fun seekBy(deltaMs: Long) = mainHandler.post {
        val p = player ?: return@post
        var target = (p.currentPosition + deltaMs).coerceAtLeast(0)
        val duration = p.duration
        if (duration != C.TIME_UNSET) {
            target = target.coerceAtMost(duration)
        }
        p.seekTo(target)
    }

    fun setSurface(surface: Surface) = mainHandler.post {
        pendingSurface = surface
        player?.setVideoSurface(surface)
    }

    // no-op if a newer surface already replaced this one
    fun clearSurface(surface: Surface) = mainHandler.post {
        if (pendingSurface !== surface) return@post
        pendingSurface = null
        player?.setVideoSurface(null)
    }

    fun stop() = mainHandler.post { _stopInternal(reportStopped = true) }

    private fun _stopInternal(reportStopped: Boolean) {
        mainHandler.removeCallbacks(_reportTick)
        mainHandler.removeCallbacks(_stallWatchdog)
        bufferingSinceMs = 0L
        readySinceMs = 0L
        consecutiveRecoveries = 0
        lastKnownLive = false
        player?.let {
            it.removeListener(_listener)
            it.release()
        }
        player = null
        // duration=-1 is the "video finished" sentinel for the playback-info handler
        if (reportStopped) {
            onPlaybackInfo?.invoke(PlaybackSnapshot(0f, -1f, 0f, false, false))
        }
    }

    private fun _reportPlaybackInfo() {
        val p = player ?: return
        val durationMs = p.duration
        val position = p.currentPosition / 1000f
        // 0 = live/unknown (TIME_UNSET); a real value only exists for vod
        val duration = if (durationMs == C.TIME_UNSET) 0f else durationMs / 1000f
        val rate = if (p.playWhenReady && p.playbackState == Player.STATE_READY) p.playbackParameters.speed else 0f
        // readyToPlay = the timeline is established, NOT exoplayer's buffering state: for vod that means the duration is known; for live there is no duration so being playable is enough. the sender holds its timeline (and /play) until this, so it must not go true early
        val ready = if (p.isCurrentMediaItemLive) p.playbackState == Player.STATE_READY
                    else durationMs != C.TIME_UNSET
        onPlaybackInfo?.invoke(
            PlaybackSnapshot(
                position = position,
                duration = duration,
                rate = rate,
                ready = ready,
                playWhenReady = p.playWhenReady,
                speed = p.playbackParameters.speed,
                skipSilence = p.skipSilenceEnabled,
                buffering = p.playbackState == Player.STATE_BUFFERING,
            )
        )
    }

    companion object {
        private const val TAG = "AirPlayVideoPlayer"
        private const val REPORT_INTERVAL_MS = 250L
        private const val WATCHDOG_INTERVAL_MS = 1_000L
        private const val VOD_BUFFERING_TIMEOUT_MS = 18_000L
        private const val LIVE_BUFFERING_TIMEOUT_MS = 12_000L
        private const val STABLE_PLAYBACK_MS = 20_000L
        private const val VOD_MAX_RECOVERIES = 1
        private const val LIVE_MAX_RECOVERIES = 3
    }
}
